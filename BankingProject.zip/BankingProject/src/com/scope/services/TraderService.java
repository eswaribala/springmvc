package com.scope.services;

import com.scope.entities.Trader;

public interface TraderService {
    void addTraderService(Trader trader);
}
