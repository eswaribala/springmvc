package com.scope.dao;

import com.scope.entities.Trader;

public interface TraderDao {

	void addTraderDao(Trader trader);
}
