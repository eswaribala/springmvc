package com.cts.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class RegisterController {

	  @RequestMapping(value = "/", method = RequestMethod.GET)
		 public String register(ModelMap model) {
		        model.addAttribute("data", "Without Web.xml Spring 4 MVC");
		        return "register";
		    }
}
